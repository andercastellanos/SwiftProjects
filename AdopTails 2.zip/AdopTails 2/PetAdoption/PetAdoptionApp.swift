//
//  Pet.swift
//  PetAdoption
//
//  Created by Andres Felipe Castellanos on 2/27/2024
//

import SwiftUI


@main


struct PetAdoptionApp: App {
    // Instantiate the shared instance of FavoritesManager
    var favoriteManager = FavoritesManager.shared
    
    // Accesing FavoritesManager using FavoritesManager.shared
    
    
    var body: some Scene {
        WindowGroup {
            ContentView()
    
            
            // Provide the FavoriteManager as an Enviroment making it accessible in Contentview
                .environmentObject(favoriteManager)
            
            
            
        }// end windowGroup
    }// end Scence
}// end PetadoptionApp
