//
//  FavoritesManager.swift
//  PetAdoption
//
//  Created by Andres Felipe Castellanos on 4/8/24.
//

import Foundation

class FavoritesManager: ObservableObject {
    static let shared = FavoritesManager()
    
    @Published var favoritePetIDs: Set<UUID> = [] {
        didSet {
            saveFavoritePetIDs()
        }
    }
    
    @Published var favorites: [Pet] = [] // Keep this if you plan to manage a runtime list of Pet objects
    
    init() {
        loadFavoritePetIDs()
    }
    
    private func saveFavoritePetIDs() {
        if let encoded = try? JSONEncoder().encode(Array(favoritePetIDs)) {
            UserDefaults.standard.set(encoded, forKey: "favoritePetIDs")
        }
    }
    
    private func loadFavoritePetIDs() {
        if let data = UserDefaults.standard.data(forKey: "favoritePetIDs"),
           let decoded = try? JSONDecoder().decode([UUID].self, from: data) {
            self.favoritePetIDs = Set(decoded)
        }
    }
    
    // Modify the logic for adding, removing, and checking favorites to work with IDs
    func add(_ pet: Pet) {
        favoritePetIDs.insert(pet.id)
        // Optionally manage the runtime list of favorite Pet objects
    }
    
    func remove(_ pet: Pet) {
        favoritePetIDs.remove(pet.id)
        // Optionally manage the runtime list of favorite Pet objects
    }
    
    func isFavorite(_ pet: Pet) -> Bool {
        favoritePetIDs.contains(pet.id)
    }
    
    // Optional: If you're maintaining a runtime list of Pet objects, implement logic to refresh this list based on favoritePetIDs
}
